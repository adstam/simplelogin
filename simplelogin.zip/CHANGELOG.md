# Changelog

## [1.1.0] - 2026-07-29

### Nieuwe functionaliteit
- **CID Embedding voor afbeeldingen**: Afbeeldingen in HTML mails worden nu embedded als CID (Content-ID) voor betere compatibiliteit en uiterlijk in e-mailclients.
- **Afbeeldingsvalidatie**: Controle op afbeeldingsgrootte (max. 500KB) en locatie (alleen `/media/` of `/images/` folders). Te grote of externe afbeeldingen worden niet embedded, maar als link getoond.
- **Image Error Logging**: Fouten bij afbeeldingsverwerking worden nu gelogd in `#__simple_login_log` met types `image_not_found` en `image_too_large`.
- **Absolute Image URLs**: Ondersteuning voor absolute URLs in afbeeldingspaden via `getAbsoluteImageUrl()`.
- **Template Validatie Popup**: Waarschuwing bij opslaan van mail templates met externe of te grote afbeeldingen.
- **Robuuste Placeholder Buttons**: Knoppen voor het invoegen van placeholders (`#name`, `#link`, `#expiry`, etc.) in mail templates, **werkend in alle editors** (TinyMCE, JCE, CodeMirror) en beide modi (text/HTML).

### Technische verbeteringen
- **Code Ontdubbeling**: Gebruik van `LogTrait::log()` voor consistent logging in plaats van duplicatie in `MailService`.
- **MailService Refactor**: Toegevoegde methodes: `getAbsoluteImageUrl()`, `getLastImageErrors()`, `validateImageForEmbedding()`.
- **Log Filter**: `ImageError` type toegevoegd aan `ReportHelper::getLogTypes()` voor filtering in de logpagina.
- **Editor Integraction**: Buttons werken nu met **alle Joomla editors** via de officiële `Joomla.editors.instances[].replaceSelection()` API.

### Bugfixes
- **Placeholder Buttons**: Opgelost dat buttons niet werkten in HTML modus (editor iframes) door editor-onafhankelijke DOM-plaatsing.
- **Image Error Logging**: Image errors worden nu correct gelogd via de bestaande `LogTrait::log()` methode.

### Technische schuld
- Vorige implementatie van placeholder buttons was afhankelijk van specifieke editor DOM structuren. Vervangen door robuuste, editor-onafhankelijke oplossing.

## [1.0.8] - 2026-07-25

### Nieuwe functionaliteit

* Onderscheid gemaakt tussen versturen van HTML opmaak of Tekst opmaak
* Voor HTML mail is de ingstelde editor toegevoegd aan de mailbody'scanner
* tabstructuur van de plugin configuratie is overzichtelijker gemaakt

## [1.0.7] - 2026-07-23

### Technical debt verwijderd

* Maillogica van de verschillende flows maakt nu gebruik van de zelfde code (ontdubbeling)
* Placeholders voor standaard strings consistent gemaakt
* Debug code uit eerdere versies verwijderd
* Inline Javascript naar externe bestanden gebracht
* Hardcoded strings opgeschoond

## [1.0.6] - 2026-07-22

### Nieuwe functionaliteit
- **Afkeurmail met reden**: Beheerders kunnen nu bij het afkeuren van een registratie een reden invoeren. Deze reden wordt meegestuurd in de afkeurmail naar de gebruiker.
- **Admin notificatiemail**: Beheerders ontvangen nu automatisch een e-mail bij nieuwe registraties (indien ingeschakeld in de plugin instellingen).
- **Tags in mail templates**: In alle mail templates kunnen nu eenvoudig placeholders worden ingevoegd via knoppen in de editor (bv. `#name`, `#email`, `#sitename`, `#reason`, `#adminlink`).

### Bugfixes
- Gebruikers ontvingen geen invite-mail na registratie door een te vroege opruiming van de sessie-marker. Opgelost door de marker alleen in `onUserAfterSave()` op te ruimen.
- Regeleinden in mail templates werden niet correct getoond in de uiteindelijke e-mail. Opgelost door `nl2br()` toe te passen in `buildMailBody()`.

### Technisch
- Toegevoegde taalstrings: `PLG_SYSTEM_SIMPLELOGIN_BTN_REASON`, `PLG_SYSTEM_SIMPLELOGIN_BTN_ADMINLINK`, `PLG_SYSTEM_SIMPLELOGIN_APPROVAL_REJECT_REASON_PROMPT`, `PLG_SYSTEM_SIMPLELOGIN_APPROVAL_REJECT_REASON_REQUIRED`.

## [1.0.5] - 2026-07-05

### Fixed
- Overlay toont nu alleen neutrale melding na link-opvraag (geen formulier meer)
- Melding "Als dit adres bekend is, is er een e-mail verzonden" heeft gebruitk bestaande 'info' stijl

### Technical Details
- `LoginFlowTrait.php`: `showLoginForm = false` en `statusType = 'info'` na succesvolle POST

## \[1.0.0] - 2026-07-05 (First publication)

### Contains

- Initial stable release
- Passwordless login via email links
- Passwordless user registration with email activation
- Comprehensive security features (rate limiting, cooldown, scanner detection)
- Full logging and monitoring
- Multi-language support (English, Dutch)
- Custom form fields (bodybuttons, contactcategory, exportlog, hashpasswords, logreport, throttlereport)

